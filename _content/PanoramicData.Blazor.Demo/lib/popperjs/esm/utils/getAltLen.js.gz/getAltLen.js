export default function getAltLen(len) {
  return len === 'width' ? 'height' : 'width';
}