export default function getAltAxis(axis) {
  return axis === 'x' ? 'y' : 'x';
}