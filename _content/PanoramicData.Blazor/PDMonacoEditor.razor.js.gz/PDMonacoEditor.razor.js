var _objRef = null;
var _disabledKeys = new Set();
var _keyEventListeners = new Map(); // Track event listeners for cleanup
var _keyContexts = new Map(); // keyId -> Map(editor -> context key that switches its do-nothing command on)

// The Monaco names of the browser key codes a key binding can be disabled for
var _monacoKeyNames = {
	8: "Backspace",
	9: "Tab",
	13: "Enter",
	27: "Escape",
	32: "Space",
	37: "LeftArrow",
	38: "UpArrow",
	39: "RightArrow",
	40: "DownArrow",
	46: "Delete",
};
var languageOptions = {};

// Characters that may start a (dotted) function name: ASCII letters, "_" and "$"
function isIdentifierStart(ch) {
	return (
		(ch >= "a" && ch <= "z") ||
		(ch >= "A" && ch <= "Z") ||
		ch === "_" ||
		ch === "$"
	);
}

// Characters that may continue a (dotted) function name: the above plus digits and "."
function isIdentifierPart(ch) {
	return isIdentifierStart(ch) || (ch >= "0" && ch <= "9") || ch === ".";
}

// Same set of characters as the regular expression class \s
function isWhitespace(ch) {
	return ch !== undefined && ch.length === 1 && ch.trim() === "";
}

// Monaco is loaded by the host page as a global script
function getMonaco() {
	return window.monaco;
}

// A thenable, so awaiting it pauses without naming Promise
function pause(ms) {
	return { then: (resolve) => setTimeout(resolve, ms) };
}

// Resolves true once the monaco global exists, or false after the timeout. editor.main.js is an AMD bundle, so
// monaco is only defined once the loader has fetched its remaining parts, which a fast reload can beat.
export async function waitForMonaco(timeoutMs) {
	const started = Date.now();
	while (!getMonaco()) {
		if (Date.now() - started >= timeoutMs) {
			return false;
		}

		await pause(50);
	}

	return true;
}

export function initialize(objRef) {
	if (objRef) {
		_objRef = objRef;
	}
}

function toKeyId(binding) {
	return `${binding.keyCode}-${binding.ctrlKey}-${binding.altKey}-${binding.shiftKey}`;
}

function fromKeyId(keyId) {
	const [keyCode, ctrlKey, altKey, shiftKey] = keyId.split("-");
	return {
		keyCode: parseInt(keyCode, 10),
		ctrlKey: ctrlKey === "true",
		altKey: altKey === "true",
		shiftKey: shiftKey === "true",
	};
}

export function disableKeyBinding(keyCode, ctrlKey, altKey, shiftKey) {
	const binding = { keyCode, ctrlKey, altKey, shiftKey };
	const keyId = toKeyId(binding);
	_disabledKeys.add(keyId);

	const monaco = getMonaco();
	if (monaco && monaco.editor) {
		monaco.editor.getEditors().forEach((editor) => {
			disableInEditor(editor, binding, keyId);
		});

		// Editors created later are given every disabled key too
		const originalCreate = monaco.editor.create;
		if (!originalCreate._pdIntercepted) {
			monaco.editor.create = function (container, options, override) {
				const editor = originalCreate.call(this, container, options, override);
				_disabledKeys.forEach((disabledKeyId) => {
					disableInEditor(editor, fromKeyId(disabledKeyId), disabledKeyId);
				});
				return editor;
			};
			originalCreate._pdIntercepted = true;
		}
	}
}

// Monaco's name for a browser key code, or undefined when it has none here.
function monacoKeyName(code) {
	const named = _monacoKeyNames[code];
	if (named) {
		return named;
	}

	if (code >= 65 && code <= 90) {
		return `Key${String.fromCharCode(code)}`;
	}

	if (code >= 48 && code <= 57) {
		return `Digit${code - 48}`;
	}

	return code >= 112 && code <= 123 ? `F${code - 111}` : undefined;
}

// The browser key as Monaco's keybinding, or null for a key it has no name for here. Ctrl is Monaco's WinCtrl on a
// Mac, where its CtrlCmd is the Command key.
function toMonacoKeybinding(monaco, binding) {
	const name = monacoKeyName(binding.keyCode);
	const keyCode = name ? monaco.KeyCode[name] : undefined;
	if (keyCode === undefined) {
		return null;
	}

	const isMac = /Mac/.test(navigator.platform);
	const ctrl = isMac ? monaco.KeyMod.WinCtrl : monaco.KeyMod.CtrlCmd;
	return (
		keyCode |
		(binding.ctrlKey ? ctrl : 0) |
		(binding.altKey ? monaco.KeyMod.Alt : 0) |
		(binding.shiftKey ? monaco.KeyMod.Shift : 0)
	);
}

// A do-nothing command of Monaco's own takes the key's place in the editor (Ctrl+Enter is its Insert Line Below),
// and the key still reaches the page's shortcuts, such as PDStudio's Run. Monaco now takes typing on a native edit
// context rather than its textarea, so catching the key on the textarea no longer stops it. A key Monaco cannot be
// given is caught there all the same.
function disableInEditor(editor, binding, keyId) {
	const monaco = getMonaco();
	const keybinding = monaco ? toMonacoKeybinding(monaco, binding) : null;
	if (keybinding === null || !editor.addCommand || !editor.createContextKey) {
		interceptKeyboardEvent(editor, binding, keyId);
		return;
	}

	let contexts = _keyContexts.get(keyId);
	if (!contexts) {
		contexts = new Map();
		_keyContexts.set(keyId, contexts);
	}

	const existing = contexts.get(editor);
	if (existing) {
		existing.set(true);
		return;
	}

	const contextName = `pdDisabled_${keyId.replaceAll("-", "_")}`;
	const contextKey = editor.createContextKey(contextName, true);
	editor.addCommand(keybinding, () => {}, contextName);
	contexts.set(editor, contextKey);
	editor.onDidDispose(() => contexts.delete(editor));
}

function findEditorInputElement(domNode) {
	return (
		domNode.querySelector(".monaco-editor textarea") ||
		domNode.querySelector(".monaco-editor input") ||
		domNode.querySelector(".view-lines")
	);
}

function createKeyEventHandler(binding, keyId) {
	return function (event) {
		const matches =
			event.keyCode === binding.keyCode &&
			event.ctrlKey === binding.ctrlKey &&
			event.altKey === binding.altKey &&
			event.shiftKey === binding.shiftKey;

		if (matches) {
			console.log(`Intercepted disabled key combination: ${keyId}`);
			event.preventDefault();
			event.stopPropagation();
			event.stopImmediatePropagation();
		}
	};
}

function interceptKeyboardEvent(editor, binding, keyId) {
	if (!editor) return;

	try {
		const domNode = editor.getDomNode();
		if (!domNode) return;

		// Find the actual editor textarea/input element
		const editorElement = findEditorInputElement(domNode);
		if (!editorElement) {
			console.warn("Could not find Monaco editor input element");
			return;
		}

		// Add the event listener with capture=true to intercept before Monaco
		const keyEventHandler = createKeyEventHandler(binding, keyId);
		editorElement.addEventListener("keydown", keyEventHandler, true);

		// Store the listener for cleanup
		if (!_keyEventListeners.has(keyId)) {
			_keyEventListeners.set(keyId, new Map());
		}
		_keyEventListeners
			.get(keyId)
			.set(editor, { element: editorElement, handler: keyEventHandler });

		console.log(`Intercepted keyboard events for key binding: ${keyId}`);
	} catch (error) {
		console.warn("Failed to intercept Monaco keyboard events:", error);
	}
}

export function enableKeyBinding(keyCode, ctrlKey, altKey, shiftKey) {
	const keyId = toKeyId({ keyCode, ctrlKey, altKey, shiftKey });

	// Remove from disabled keys
	_disabledKeys.delete(keyId);

	// The do-nothing commands stand aside, so the editor's own take the key again
	_keyContexts.get(keyId)?.forEach((contextKey) => contextKey.set(false));

	// Remove all event listeners for this key combination
	if (_keyEventListeners.has(keyId)) {
		_keyEventListeners.get(keyId).forEach(({ element, handler }) => {
			element.removeEventListener("keydown", handler, true);
		});
		_keyEventListeners.delete(keyId);
		console.log(`Re-enabled key binding: ${keyId}`);
	}
}

export function registerLanguage(id, language) {
	const monaco = getMonaco();
	if (!monaco) {
		return false;
	}

	// does language already exist?
	const exists = monaco.languages.getLanguages().some((obj) => obj.id === id);
	if (exists) {
		return false;
	}
	monaco.languages.register({ id: id });
	if (language.showCompletions) {
		monaco.languages.registerCompletionItemProvider(id, {
			provideCompletionItems: getCompletions,
			resolveCompletionItem: resolveCompletionItem,
		});
		if (language.signatureHelpTriggers) {
			monaco.languages.registerSignatureHelpProvider(id, {
				provideSignatureHelp: getSignatureHelp,
				signatureHelpTriggerCharacters: language.signatureHelpTriggers,
			});
		}
	}

	languageOptions[id] = language;
	return true;
}

function findParameterIndex(functionsArray, property, value) {
	for (const func of functionsArray) {
		const index = func.parameters.findIndex(
			(param) =>
				param[property] === value || param[property] === "[" + value + "]",
		);
		if (index !== -1) {
			return index;
		}
	}
	return -1; // No match found
}

function getActiveParameter(model, position, language, signatures) {
	const textUntilPosition = model.getValueInRange({
		startLineNumber: position.lineNumber,
		startColumn: 1,
		endLineNumber: position.lineNumber,
		endColumn: position.column,
	});

	// optional parameter? value= or value:
	var optionalPostfix = languageOptions[language].optionalParameterPostfix;
	if (optionalPostfix && signatures.length > 0) {
		var paramName = getLastWordBeforeCharSinceComma(
			textUntilPosition,
			optionalPostfix,
		);
		if (paramName) {
			const index = findParameterIndex(signatures, "label", paramName);
			if (index !== -1) {
				return index;
			}
		}
	}

	// basic counting of commas since opening delimiter
	var delimiter = languageOptions[language].functionDelimiter;
	const openParenthesisIndex = textUntilPosition.lastIndexOf(delimiter);
	if (openParenthesisIndex === -1) {
		return 0;
	}
	const paramsString = textUntilPosition.substring(openParenthesisIndex + 1);
	return paramsString.split(",").length - 1;
}

function getActiveSignature(signatures, activeParameter) {
	// selects first signature with at least N parameters
	for (let i = 0; i < signatures.length; i++) {
		if (signatures[i].parameters.length >= activeParameter + 1) {
			return i;
		}
	}
	return 0; // unknown - return first
}

function getTextUntilPosition(model, position) {
	return model.getValueInRange({
		startLineNumber: 1,
		startColumn: 1,
		endLineNumber: position.lineNumber,
		endColumn: position.column,
	});
}

async function getCompletions(model, position) {
	var textUntilPosition = getTextUntilPosition(model, position);

	var language = model.getLanguageId();
	var functionName = getLastFunctionName(textUntilPosition, language);

	var word = model.getWordUntilPosition(position);
	var range = {
		startLineNumber: position.lineNumber,
		endLineNumber: position.lineNumber,
		startColumn: word.startColumn,
		endColumn: word.endColumn,
	};

	// call out to C# to fetch completion items
	var items = [];
	if (_objRef) {
		items = await _objRef.invokeMethodAsync(
			"GetCompletions",
			range,
			functionName,
		);
	}

	// return result
	return { suggestions: items };
}

// Index of the first character at or after index that does not satisfy the predicate
function skipWhile(text, index, predicate) {
	let end = index;
	while (end < text.length && predicate(text[end])) {
		end++;
	}
	return end;
}

// Index just after the delimiter that follows position nameEnd (optionally after whitespace), or -1
function findDelimiterEnd(text, nameEnd, delimiter) {
	// Prefer the most whitespace before the delimiter
	const whitespaceEnd = skipWhile(text, nameEnd, isWhitespace);
	for (let index = whitespaceEnd; index >= nameEnd; index--) {
		if (text[index] === delimiter) {
			return index + 1;
		}
	}
	return -1;
}

/**
 * Tries to match "identifier, optional whitespace, delimiter" starting at index start
 * (the identifier may contain dots). Returns { name, end } or null.
 */
function matchFunctionCallAt(text, start, delimiter) {
	if (!isIdentifierStart(text[start])) {
		return null;
	}

	// Prefer the longest identifier
	const identifierEnd = skipWhile(text, start + 1, isIdentifierPart);
	for (let nameEnd = identifierEnd; nameEnd > start; nameEnd--) {
		const end = findDelimiterEnd(text, nameEnd, delimiter);
		if (end !== -1) {
			return { name: text.slice(start, nameEnd), end };
		}
	}

	return null;
}

function getLastFunctionName(text, language) {
	// find the last function name followed by the language's opening delimiter
	const delimiter = languageOptions[language].functionDelimiter;
	let lastFunctionName = null;
	let index = 0;
	while (index < text.length) {
		const match = matchFunctionCallAt(text, index, delimiter);
		if (match) {
			lastFunctionName = match.name;
			index = match.end;
		} else {
			index++;
		}
	}
	return lastFunctionName;
}

function getLastWordBeforeCharSinceComma(text, postfix) {
	// Find the index of the last comma in the string
	const lastCommaIndex = text.lastIndexOf(",");

	// Find the index of the last postfix character in the string
	const lastPostfixIndex = text.lastIndexOf(postfix);

	// If no postfix or no comma is found, return null
	if (lastPostfixIndex === -1) {
		return null; // No postfix character found
	}

	// Slice the string from the last comma (or start of string if no comma)
	const relevantText =
		lastCommaIndex !== -1
			? text.slice(lastCommaIndex + 1, lastPostfixIndex)
			: text.slice(0, lastPostfixIndex);

	// Find the last word in the relevant portion of the string
	const regex = /(\b\w+)\s*$/;
	const match = relevantText.match(regex);

	// Return the last word if found, otherwise return null
	return match ? match[1] : null;
}

async function getSignatureHelp(model, position) {
	var language = model.getLanguageId();

	// determine current function
	var textUntilPosition = getTextUntilPosition(model, position);
	var functionName = getLastFunctionName(textUntilPosition, language);

	// call out to C# to fetch signatures
	var signatures = [];
	if (_objRef) {
		signatures = await _objRef.invokeMethodAsync("GetSignatures", functionName);
	}

	let activeParameter;
	let activeSignature;
	if (signatures.length > 0) {
		activeParameter = getActiveParameter(model, position, language, signatures);
		activeSignature = getActiveSignature(signatures, activeParameter);
	}

	// return result
	const value = { signatures, activeSignature, activeParameter };
	const result = { value, dispose: function () {} };
	return result;
}

async function resolveCompletionItem(item) {
	if (_objRef) {
		await _objRef.invokeMethodAsync("ResolveCompletionAsync", item.label);
	}
}
