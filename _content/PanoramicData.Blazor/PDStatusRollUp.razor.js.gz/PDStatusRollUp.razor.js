// =================================================================
// PDStatusRollUp.razor.js — Blazor JS module
// Cascade pop-over engine.  Three exported functions:
//   init(triggerId, nodeJson, iconMap, dotNetRef?)
//   update(triggerId, nodeJson)
//   dispose(triggerId)
// =================================================================

const MAX_DEPTH = 2;

// Per-trigger state: triggerId → { node, iconMap, el, abortCtrl, dotNetRef? }
const _triggers = new Map();

// Shared DOM infrastructure (created once on first init)
let _infra = null; // { overlay, popups[] }

// The trigger ID whose popup stack is currently open
let _activeId = null;

// ── Public API ────────────────────────────────────────────────────

export function init(triggerId, nodeJson, iconMap, dotNetRef) {
	_ensureInfra();

	const el = document.getElementById(triggerId);
	if (!el) return;

	const node = typeof nodeJson === "string" ? JSON.parse(nodeJson) : nodeJson;
	const abortCtrl = new AbortController();
	const opts = { signal: abortCtrl.signal };

	_triggers.set(triggerId, {
		node,
		iconMap,
		el,
		abortCtrl,
		dotNetRef: dotNetRef ?? null,
	});

	el.addEventListener(
		"click",
		async (e) => {
			e.stopPropagation();
			if (_activeId === triggerId) {
				_closeAll();
			} else {
				_closeAll();
				await _open(triggerId);
			}
		},
		opts,
	);

	el.addEventListener(
		"keydown",
		(e) => {
			if (e.key === "Enter" || e.key === " ") {
				e.preventDefault();
				el.click();
			}
			if (e.key === "Escape") _closeAll();
		},
		opts,
	);
}

// Replaces the snapshot the pop-over is drawn from. The trigger icon is rendered by Blazor and so
// follows the node on every render; without this the pop-over would go on describing the node as it
// was when the component first rendered, which reads as an icon and a pop-over that disagree.
export function update(triggerId, nodeJson) {
	const entry = _triggers.get(triggerId);
	if (!entry) return;

	entry.node = typeof nodeJson === "string" ? JSON.parse(nodeJson) : nodeJson;

	// Redraw an open pop-over from the root, so a status that changes while someone is looking at it
	// is not left showing the superseded verdict. Any drill-down is closed by this, which is the
	// honest outcome: the children it was showing may no longer exist.
	if (_activeId === triggerId) {
		_closeFrom(1);
		_renderPopup(0, entry.node, entry.el, entry.iconMap, entry, "");
	}
}

export function dispose(triggerId) {
	const entry = _triggers.get(triggerId);
	if (entry) {
		entry.abortCtrl.abort(); // removes all listeners attached with { signal }
		_triggers.delete(triggerId);
	}
	if (_activeId === triggerId) _closeAll();
}

// ── Infrastructure ────────────────────────────────────────────────

function _ensureInfra() {
	if (_infra) return;

	// Inject popup styles once
	if (!document.getElementById("pdsr-global-styles")) {
		const style = document.createElement("style");
		style.id = "pdsr-global-styles";
		style.textContent = _GLOBAL_STYLES;
		document.head.appendChild(style);
	}

	// Transparent overlay — click dismisses the popup stack
	const overlay = document.createElement("div");
	overlay.id = "pdsr-overlay";
	overlay.className = "pdsr-overlay";
	overlay.addEventListener("click", () => _closeAll());
	overlay.addEventListener("keydown", (e) => {
		if (e.key === "Escape") _closeAll();
	});
	document.body.appendChild(overlay);

	// Three popup layers (depth 0, 1, 2)
	const popups = [];
	for (let i = 0; i <= MAX_DEPTH; i++) {
		const popup = document.createElement("div");
		popup.className = "pdsr-popup";
		popup.dataset.depth = i;
		popup.setAttribute("role", i === 0 ? "dialog" : "region");
		popup.addEventListener("click", (e) => e.stopPropagation());
		document.body.appendChild(popup);
		popups.push(popup);
	}

	_infra = { overlay, popups };
}

// ── Open / Close ──────────────────────────────────────────────────

async function _open(triggerId) {
	const entry = _triggers.get(triggerId);
	if (!entry) return;

	_activeId = triggerId;
	entry.el.setAttribute("aria-expanded", "true");
	_infra.overlay.classList.add("pdsr-overlay--active");

	const node = await _maybeExpand(entry, entry.node, "", entry.el);
	_renderPopup(0, node, entry.el, entry.iconMap, entry, "");
}

function _closeAll() {
	if (_activeId) {
		const entry = _triggers.get(_activeId);
		if (entry) entry.el.setAttribute("aria-expanded", "false");
		_activeId = null;
	}
	if (_infra) {
		_infra.overlay.classList.remove("pdsr-overlay--active");
		_infra.popups.forEach((p) => {
			p.classList.remove("pdsr-popup--open");
			p.textContent = "";
		});
	}
}

function _closeFrom(depth) {
	if (!_infra) return;
	for (let i = depth; i <= MAX_DEPTH; i++) {
		_infra.popups[i].classList.remove("pdsr-popup--open");
		_infra.popups[i].textContent = "";
	}
}

// ── Lazy expansion helper ─────────────────────────────────────────

// Shows a spinner in the popup at `depth` while the .NET callback runs.
// Returns the (possibly updated) node.
async function _maybeExpand(entry, node, nodePath, anchorEl) {
	if (!entry.dotNetRef) return node;

	const depth = nodePath === "" ? 0 : nodePath.split(".").length;
	const popup = _infra.popups[Math.min(depth, MAX_DEPTH)];

	// Show spinner while awaiting, positioned next to the element that was clicked
	popup.textContent = "";
	popup.appendChild(_createSpinner());
	_positionPopup(popup, anchorEl, depth);
	popup.classList.add("pdsr-popup--open");

	try {
		const json = await entry.dotNetRef.invokeMethodAsync(
			"ExpandNodeAsync",
			nodePath,
		);
		if (json) {
			return JSON.parse(json);
		}
	} catch {
		// Ignore — fall through to render with existing node
	}

	return node;
}

// ── Popup Rendering ───────────────────────────────────────────────

function _text(value) {
	return value ? String(value) : "";
}

function _createElement(tagName, className, text) {
	const element = document.createElement(tagName);
	if (className) element.className = className;
	if (text !== undefined) element.textContent = _text(text);
	return element;
}

function _createIcon(className) {
	const icon = _createElement("i", className);
	icon.setAttribute("aria-hidden", "true");
	return icon;
}

function _statusIconClass(status, iconMap) {
	return `${_iconClass(status, iconMap)} ${_colorClass(status)}`;
}

function _createSpinner() {
	const spinner = _createElement("div", "pdsr-spinner");
	spinner.appendChild(_createElement("i", "fas fa-spinner fa-spin"));
	return spinner;
}

function _createHeader(node, iconMap) {
	const head = _createElement("div", "pdsr-popup-head");

	const titleRow = _createElement("div", "pdsr-popup-title-row");
	titleRow.appendChild(_createIcon(_statusIconClass(node.status, iconMap)));
	titleRow.appendChild(_createElement("span", "pdsr-popup-title", node.title));
	head.appendChild(titleRow);

	if (node.summary) {
		head.appendChild(_createElement("p", "pdsr-popup-summary", node.summary));
	}
	if (node.detail) {
		head.appendChild(_createElement("p", "pdsr-popup-detail", node.detail));
	}
	return head;
}

// Expandable tri-state: true=force on, false=force off, null/undefined=auto (has children)
function _isDrillable(child, depth) {
	if (depth >= MAX_DEPTH) return false;
	if (child.expandable === true) return true;
	const hasChildren = child.children && child.children.length > 0;
	return child.expandable !== false && hasChildren;
}

function _createItem(child, idx, drillable, iconMap) {
	const item = _createElement(
		"div",
		drillable ? "pdsr-item pdsr-item--drillable" : "pdsr-item",
	);
	item.dataset.idx = idx;
	item.setAttribute("role", drillable ? "button" : "listitem");
	if (drillable) item.setAttribute("tabindex", "0");

	item.appendChild(_createIcon(_statusIconClass(child.status, iconMap)));

	const body = _createElement("div", "pdsr-item-body");
	body.appendChild(_createElement("span", "pdsr-item-label", child.title));
	if (child.summary) {
		body.appendChild(
			_createElement("span", "pdsr-item-summary", child.summary),
		);
	}
	item.appendChild(body);

	if (child.detail) {
		const aside = _createElement(
			"i",
			"fa-solid fa-circle-info pdsr-item-aside",
		);
		aside.setAttribute("title", _text(child.detail));
		aside.setAttribute("aria-label", "Has detail");
		item.appendChild(aside);
	}
	if (drillable) {
		item.appendChild(_createIcon("fas fa-chevron-right pdsr-item-chevron"));
	}
	return item;
}

function _attachDrillHandler(popup, item, context) {
	const { depth, node, iconMap, entry, nodePath } = context;
	const idx = parseInt(item.dataset.idx, 10);
	const childPath = nodePath === "" ? `${idx}` : `${nodePath}.${idx}`;

	const drill = async (e) => {
		e.stopPropagation();
		_closeFrom(depth + 1);
		popup
			.querySelectorAll(".pdsr-item")
			.forEach((i) => i.classList.remove("pdsr-item--active"));
		item.classList.add("pdsr-item--active");
		const childNode = await _maybeExpand(
			entry,
			node.children[idx],
			childPath,
			item,
		);
		// Update the in-memory child so subsequent opens reflect the fetched status
		node.children[idx] = childNode;
		// Patch the row icon/colour in the parent popup to reflect the resolved status
		_updateItemIcon(item, childNode.status, iconMap);
		_renderPopup(depth + 1, childNode, item, iconMap, entry, childPath);
	};

	item.addEventListener("click", drill);
	item.addEventListener("keydown", (e) => {
		if (e.key === "Enter" || e.key === " ") {
			e.preventDefault();
			drill(e);
		}
	});
}

function _renderPopup(depth, node, anchorEl, iconMap, entry, nodePath) {
	if (depth > MAX_DEPTH) return;

	const popup = _infra.popups[depth];
	popup.textContent = "";
	popup.appendChild(_createHeader(node, iconMap));

	// ── Children (with drill-down handlers) ──
	if (node.children && node.children.length > 0) {
		const body = _createElement("div", "pdsr-popup-body");
		const context = { depth, node, iconMap, entry, nodePath };
		node.children.forEach((child, idx) => {
			const drillable = _isDrillable(child, depth);
			const item = _createItem(child, idx, drillable, iconMap);
			if (drillable) _attachDrillHandler(popup, item, context);
			body.appendChild(item);
		});
		popup.appendChild(body);
	}

	// ── Position and show ──
	_positionPopup(popup, anchorEl, depth);
	popup.classList.add("pdsr-popup--open");
}

function _positionPopup(popup, anchor, depth) {
	// Measure before making visible
	popup.style.visibility = "hidden";
	popup.style.display = "block";

	const rect = anchor.getBoundingClientRect();
	const pw = popup.offsetWidth || 280;
	const ph = popup.offsetHeight || 200;
	const vw = window.innerWidth;
	const vh = window.innerHeight;

	let left, top;

	if (depth === 0) {
		// Below the trigger, aligned to its left edge
		left = rect.left;
		top = rect.bottom + 4;
		// Flip right-to-left if it would overflow the right edge
		if (left + pw > vw - 8) left = Math.max(8, rect.right - pw);
	} else {
		// To the right of the parent item
		left = rect.right + 4;
		top = rect.top;
		// Flip to the left if it would overflow the right edge
		if (left + pw > vw - 8) left = Math.max(8, rect.left - pw - 4);
	}

	// Clamp within the vertical viewport
	if (top + ph > vh - 8) top = Math.max(8, vh - ph - 8);

	popup.style.left = `${left}px`;
	popup.style.top = `${top}px`;
	popup.style.visibility = "";
	popup.style.display = "";
}

// ── Helpers ───────────────────────────────────────────────────────

// Patches the icon element inside a .pdsr-item row to reflect a newly resolved status.
// Called after _maybeExpand returns so the parent popup row updates without a full re-render.
function _updateItemIcon(itemEl, status, iconMap) {
	const icon = itemEl.querySelector("i:first-child");
	if (!icon) return;
	// Strip existing colour and icon classes, then apply the resolved ones
	icon.className = _statusIconClass(status, iconMap);
}

// Status name → { icon map key, default icon, colour class }; anything else is shown as gray
const _STATUS_STYLES = new Map([
	[
		"red",
		{ key: "red", icon: "fa-solid fa-circle-xmark", color: "text-danger" },
	],
	[
		"amber",
		{
			key: "amber",
			icon: "fa-solid fa-triangle-exclamation",
			color: "pdsr-icon-amber",
		},
	],
	[
		"green",
		{ key: "green", icon: "fa-solid fa-circle-check", color: "text-success" },
	],
]);
const _GRAY_STYLE = {
	key: "gray",
	icon: "fa-solid fa-circle-question",
	color: "text-secondary",
};

function _statusStyle(status) {
	return _STATUS_STYLES.get((status || "").toLowerCase()) || _GRAY_STYLE;
}

function _iconClass(status, iconMap) {
	const style = _statusStyle(status);
	return (iconMap && iconMap[style.key]) || style.icon;
}

function _colorClass(status) {
	return _statusStyle(status).color;
}

// ── Global popup styles (injected once) ───────────────────────────

const _GLOBAL_STYLES = `
/* PDStatusRollUp — popup styles */
.pdsr-overlay {
	display: none;
	position: fixed;
	inset: 0;
	z-index: 1040;
}
.pdsr-overlay--active {
	display: block;
}
.pdsr-popup {
	display: none;
	position: fixed;
	z-index: 1050;
	width: 280px;
	background: var(--bs-body-bg, #fff);
	color: var(--bs-body-color, #212529);
	border: 1px solid var(--bs-border-color, rgba(0,0,0,.15));
	border-radius: .375rem;
	box-shadow: 0 .5rem 1rem var(--bs-border-color-translucent, rgba(0,0,0,.15));
	font-size: .875rem;
	overflow: hidden;
}
.pdsr-popup--open {
	display: block;
}
.pdsr-popup-head {
	padding: .6rem .75rem .5rem;
	border-bottom: 1px solid var(--bs-border-color, rgba(0,0,0,.08));
	background: var(--bs-tertiary-bg, rgba(0,0,0,.025));
	user-select: none;
}
.pdsr-popup-title-row {
	display: flex;
	align-items: center;
	gap: .45rem;
	font-weight: 600;
}
.pdsr-popup-title-row i {
	line-height: 1;
	font-size: .85rem;
	flex-shrink: 0;
}
.pdsr-popup-title {
	font-size: .875rem;
}
.pdsr-popup-summary {
	margin: .35rem 0 0;
	font-size: .8rem;
	color: var(--bs-secondary-color, #6c757d);
	line-height: 1.4;
}
.pdsr-popup-detail {
	margin: .25rem 0 0;
	font-size: .75rem;
	color: var(--bs-secondary-color, #868e96);
	font-family: monospace;
	word-break: break-all;
	line-height: 1.4;
}
.pdsr-popup-body {}
.pdsr-item {
	display: flex;
	align-items: flex-start;
	gap: .5rem;
	padding: .45rem .75rem;
	border-bottom: 1px solid var(--bs-border-color, rgba(0,0,0,.06));
	cursor: default;
	user-select: none;
}
.pdsr-item:last-child {
	border-bottom: none;
}
.pdsr-item > i:first-child {
	line-height: 1;
	margin-top: .15rem;
	flex-shrink: 0;
	font-size: .8rem;
}
.pdsr-item--drillable {
	cursor: pointer;
	transition: background .12s;
}
.pdsr-item--drillable:hover {
	background: var(--bs-tertiary-bg, rgba(0,0,0,.04));
}
.pdsr-item--active {
	background: var(--bs-secondary-bg, rgba(0,0,0,.06));
}
.pdsr-item-body {
	flex: 1;
	min-width: 0;
	display: flex;
	flex-direction: column;
	gap: .1rem;
}
.pdsr-item-label {
	font-weight: 500;
	font-size: .8rem;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
}
.pdsr-item-summary {
	font-size: .75rem;
	color: var(--bs-secondary-color, #6c757d);
	line-height: 1.35;
}
.pdsr-item-aside {
	color: var(--bs-secondary-color, #adb5bd);
	font-size: .7rem;
	margin-top: .2rem;
	flex-shrink: 0;
}
.pdsr-item-chevron {
	color: var(--bs-secondary-color, #adb5bd);
	font-size: .7rem;
	margin-top: .2rem;
	flex-shrink: 0;
}
/* Amber is the only custom status colour — Bootstrap text-warning is too pale for icons.
   Override with --pdsr-color-amber on any ancestor element if needed. */
.pdsr-icon-amber { color: var(--pdsr-color-amber, #fd7e14); }
/* Loading spinner shown during lazy expansion */
.pdsr-spinner {
	display: flex;
	align-items: center;
	justify-content: center;
	padding: 1rem;
	color: var(--bs-secondary-color, #6c757d);
}
`;
